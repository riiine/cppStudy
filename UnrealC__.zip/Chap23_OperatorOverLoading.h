// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Chap23_OperatorOverLoading.generated.h"

/**
�׽�Ʈ�� ���ؼ� Point1��� �̸��� Ŭ������ ������ �ֵ��� �մϴ�.
*/
class Point1
{
private:
	int32 XPosition;
	int32 YPosition;

public:
	Point1(int32 X, int32 Y) : XPosition(X), YPosition(Y) {}
	
	void ShowPosition()
	{
		UE_LOG(LogTemp, Warning, TEXT("XPosition : %d, YPosition : %d"), XPosition, YPosition);
	}
};

/**
�׽�Ʈ�� ���ؼ� Point2��� �̸��� Ŭ������ ������ �ֵ��� �մϴ�.
*/
class Point2
{
private:
	int32 XPosition;
	int32 YPosition;
public:

	Point2(int32 X, int32 Y) : XPosition(X), YPosition(Y) {}

	Point2 Add(Point2& Position)
	{
		Point2 pt(XPosition + Position.XPosition, YPosition + Position.YPosition);
		return pt;
	}

	Point2 operator+(Point2& Position)
	{
		Point2 pt(XPosition + Position.XPosition, YPosition + Position.YPosition);
		return pt;
	}

	void ShowPosition()
	{
		UE_LOG(LogTemp, Warning, TEXT("XPosition : %d, YPosition : %d"), XPosition, YPosition);
	}
};

/**
�׽�Ʈ�� ���ؼ� Point3��� �̸��� Ŭ������ ������ �ֵ��� �մϴ�.
*/
class Point3
{
private:
	int32 XPosition;
	int32 YPosition;
public:
	Point3(int x, int y) : XPosition(x), YPosition(y) {}
	
	Point3 Add(Point3& position)
	{
		Point3 pt(XPosition + position.XPosition, YPosition + position.YPosition);
		return pt;
	}

	bool EqualTo(Point3& position)
	{
		return ((XPosition == position.XPosition) && (YPosition == position.YPosition));
	}

	bool NotEqualTo(Point3& position)
	{
		return !(*this == position);
	}

	Point3 operator+(Point3& position)
	{
		Point3 pt(XPosition + position.XPosition, YPosition + position.YPosition);
		return pt;
	}

	bool operator==(Point3& position)
	{
		return ((XPosition == position.XPosition) && (YPosition == position.YPosition));
	}

	bool operator!=(Point3& position)
	{
		return !(*this == position);
	}

	void ShowPosition()
	{
		UE_LOG(LogTemp, Warning, TEXT("XPosition : %d, YPosition : %d"), XPosition, YPosition);
	}
};


/**
�׽�Ʈ�� ���ؼ� Point4��� �̸��� Ŭ������ ������ �ֵ��� �մϴ�.
*/
class Point4
{
private:
	int XPosition;
	int YPosition;
public:
	Point4(int x, int y) : XPosition(x), YPosition(y) {}
	
	Point4 operator+(Point4& position)
	{
		Point4 pt(XPosition + position.XPosition, YPosition + position.YPosition);
		return pt;
	}

	Point4 operator-(Point4& position)
	{
		Point4 pt(XPosition - position.XPosition, YPosition - position.YPosition);
		return pt;
	}

	Point4 operator*(Point4& position)
	{
		Point4 pt(XPosition * position.XPosition, YPosition * position.YPosition);
		return pt;
	}

	Point4 operator/(Point4& position)
	{
		Point4 pt(XPosition / position.XPosition, YPosition / position.YPosition);
		return pt;
	}

	Point4 operator%(Point4& position)
	{
		Point4 pt(XPosition % position.XPosition, YPosition % position.YPosition);
		return pt;
	}

	bool operator==(Point4& position)
	{
		return ((XPosition == position.XPosition) && (YPosition == position.YPosition));
	}

	bool operator!=(Point4& position)
	{
		return !(*this == position);
	}

	Point4 operator++() // ++Point4	
	{
		++XPosition;
		++YPosition;
		return *this;
	}

	Point4 operator++(int) // Point4++
	{
		Point4 pt = *this;
		XPosition++;
		YPosition++;
		return pt;
	}

	Point4 operator--() // --Point4	
	{
		--XPosition;
		--YPosition;
		return *this;
	}

	Point4 operator--(int) // Point4--
	{
		Point4 pt = *this;
		XPosition--;
		YPosition--;
		return pt;
	}

	void ShowPosition()
	{
		UE_LOG(LogTemp, Warning, TEXT("XPosition : %d, YPosition : %d"), XPosition, YPosition);
	}
};



UCLASS()
class UNREALCPP_API AChap23_OperatorOverLoading : public AActor
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	AChap23_OperatorOverLoading();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

};
